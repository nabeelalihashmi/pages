# a



---

## Step 1: Scroll down

![Step 1](a/step-1.jpg)

## Step 2: Click "Builder" link

![Step 2](a/step-2.jpg)

## Step 3: Click "Create New Form" button

![Step 3](a/step-3.jpg)

## Step 4: Click "e.g., Customer Feedback" in dialog

![Step 4](a/step-4.jpg)

## Step 5: Type "My Form" in "Form Name"

![Step 5](a/step-5.jpg)

## Step 6: Click "Conversational" in dialog

![Step 6](a/step-6.jpg)

## Step 7: Click "Create Form" button in dialog

![Step 7](a/step-7.jpg)

## Step 8: Type "multistep" in "Conversational"

![Step 8](a/step-8.jpg)

## Step 9: Click "Add Field" button

![Step 9](a/step-9.jpg)

## Step 10: Click "Text" button

![Step 10](a/step-10.jpg)

## Step 11: Click element

![Step 11](a/step-11.jpg)

## Step 12: Type "Enter something." in "Write here..."

![Step 12](a/step-12.jpg)

## Step 13: Type "Please enter something. anythi..." in "Write here..."

![Step 13](a/step-13.jpg)

## Step 14: Click "Save" button in navigation

![Step 14](a/step-14.jpg)

## Step 15: Click element

![Step 15](a/step-15.jpg)

## Step 16: Click "Advanced" button → Click "General" button → Click element → Click element

**Actions performed:**

1. Click "Advanced" button
2. Click "General" button
3. Click element
4. Click element

![Step 16](a/step-16.jpg)

